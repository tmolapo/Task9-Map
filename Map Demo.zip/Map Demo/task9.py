#import libraries
import folium
from folium import IFrame
import pandas
import os
import base64

#create a map variable
map = folium.Map(location=[-29.609988,28.233608],zoom_start=7.5)

#icon customized markers
logoIcon=folium.features.CustomIcon('MASERU-BORDER.jpg', icon_size=(65,65))

logoIcon2=folium.features.CustomIcon('46453563632_16e29eda39_b.jpg', icon_size=(65,65))


logoIcon3=folium.features.CustomIcon('download.jpg', icon_size=(65,65))


logoIcon4=folium.features.CustomIcon('download.jpg', icon_size=(65,65))

#geojson data
overlay = os.path.join('data','overlay2.json')

#tooltip variable
tooltip = "Click for more"

#html to hold and convert image
html = '<img src="data:image/png;base64,{}">'.format

#creating variable to hold image1
picture1 = base64.b64encode(open('./images/image.png','rb').read()).decode()
#create variable to hold the iframe object
IFrame1 = IFrame(html(picture1), width=300+ 20, height=300+20)
#variable to hold the outer frame
popup1 =folium.Popup(IFrame1,max_width=550)
#create variable to hold icon
icon1 = folium.Icon(color="pink")


#creating variable to hold image2
picture2 = base64.b64encode(open('./images/48747150.png','rb').read()).decode()
#create variable to hold the iframe object
IFrame2 = IFrame(html(picture2), width=300+ 20, height=300+20)
#variable to hold the outer frame
popup2 =folium.Popup(IFrame2,max_width=550)
#create variable to hold icon
icon2 = folium.Icon(color="red")

#creating variable to hold image2
picture3 = base64.b64encode(open('./images/mokorotlo.png','rb').read()).decode()
#create variable to hold the iframe object
IFrame3 = IFrame(html(picture3), width=300+ 20, height=300+20)
#variable to hold the outer frame
popup3 =folium.Popup(IFrame3,max_width=550)
#create variable to hold icon
icon3 = folium.Icon(color="darkblue")

#creating variable to hold image2
picture4 = base64.b64encode(open('./images/mount.png','rb').read()).decode()
#create variable to hold the iframe object
IFrame4 = IFrame(html(picture4), width=300+ 20, height=300+20)
#variable to hold the outer frame
popup4 =folium.Popup(IFrame4,max_width=550)
#create variable to hold icon
icon4 = folium.Icon(color="darkpurple")

#creating variable to hold image2
picture5 = base64.b64encode(open('./images/water.png','rb').read()).decode()
#create variable to hold the iframe object
IFrame5 = IFrame(html(picture5), width=300+ 20, height=300+20)
#variable to hold the outer frame
popup5 =folium.Popup(IFrame5,max_width=550)
#create variable to hold icon
icon5 = folium.Icon(color="cadetblue")


#variable where the first image will show
marker1 = folium.Marker([-28.863918426224537,28.05908203125],
                        popup=popup1,
                        tooltip=tooltip,
                        icon=icon1).add_to(map),

#variable where the first image will show
marker2 = folium.Marker([-29.10897615145303,28.883056640624996],
                        popup=popup2,
                        tooltip=tooltip,
                        icon=icon2).add_to(map),

#variable where the first image will show
marker3 = folium.Marker([-30.00727392350453,28.1744384765625],
                        popup=popup3,
                        tooltip=tooltip,
                        icon=icon3).add_to(map),

#variable where the first image will show
marker4 = folium.Marker([-30.63318556699761,27.9327392578125],
                        popup=popup4,
                        tooltip=tooltip,
                        icon=icon4).add_to(map),

#variable where the first image will show
marker5 = folium.Marker([-29.635545914466675,27.0703125],
                        popup=popup5,
                        tooltip=tooltip,
                        icon=icon5).add_to(map),





#marker with color
folium.Marker([-29.1226,26.2131],
              popup='<strong>Central University of Technology</strong>',
              icon=folium.Icon(color='red')).add_to(map)


folium.Marker([-28.23078,28.30707],
              popup='<strong>Bethlehem</strong>',
              icon=folium.Icon(color='gray')).add_to(map)


folium.Marker([-29.8421,28.0497],
              popup='<strong>Semonkong</strong>',
              icon=folium.Icon(color='green')).add_to(map)


folium.Marker([-29.4413,27.7048],
              popup='<strong>Roma</strong>',
              icon=folium.Icon(color='beige')).add_to(map)



#creating markers
folium.Marker([-29.1472,27.7490],
               popup='<strong>Lesotho, Teyateyaneng</strong>').add_to(map)


folium.Marker([-30.40001,27.70027],
               popup='<strong>Quthing</strong>').add_to(map)


folium.Marker([-28.8778,27.8663],
               popup='<strong>Ficksburg</strong>').add_to(map)


#marker with image
folium.Marker([-29.1945,27.4574],
              popup='<strong>Ladybrand border gate</strong>',
              icon=logoIcon).add_to(map)


folium.Marker([-29.2876,29.0605],
              popup='<strong>Mokhotlong</strong>',
              icon=logoIcon2).add_to(map)


folium.Marker([-29.3355,28.5037],
              popup='<strong>Katse Dam</strong>',
              icon=logoIcon3).add_to(map)


folium.Marker([-30.15137,27.47691],
              popup='<strong>Mohales Hoek</strong>',
              icon=logoIcon4).add_to(map)



#circular marker
folium.CircleMarker(location=[-30.1115,28.6790],
                    radius=30,
                    color='#550000',
                    fill=True,
                    fill_color='#550000').add_to(map)


folium.CircleMarker(location=[-29.8224,27.2388],
                    radius=30,
                    color='#806C15',
                    fill=True,
                    fill_color='#806C15').add_to(map)



folium.CircleMarker(location=[-28.5167,28.4167],
                    radius=30,
                    color='#74276D',
                    fill=True,
                    fill_color='#74276D').add_to(map)



#GeoJson overlay
folium.GeoJson(overlay, name='area').add_to(map)



#saving file as an .html file
map.save('task9.html')
