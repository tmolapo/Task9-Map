#import libraries
import folium
from folium import IFrame
import pandas
import os
import base64


#create a map variable
map = folium.Map(location=[-26.20227,28.04363],zoom_start=7)

#create a variable to hold our image
# also setting the width and height
logoIcon=folium.features.CustomIcon('PICTURE.jpg', icon_size=(65,65))

#geojson data
overlay = os.path.join('data','overlay.json')

#tooltip variable
tooltip = "Click for more"

#html to hold and convert image
html = '<img src="data:image/png;base64,{}">'.format

#creating variable to hold image1
picture1 = base64.b64encode(open('./images/facebook.png','rb').read()).decode()
#create variable to hold the iframe object
IFrame1 = IFrame(html(picture1), width=300+ 20, height=300+20)
#variable to hold the outer frame
popup1 =folium.Popup(IFrame1,max_width=550)
#create variable to hold icon
icon1 = folium.Icon(color="blue")

#creating variable to hold image2
picture2 = base64.b64encode(open('./images/image3.png','rb').read()).decode()
#create variable to hold the iframe object
IFrame2 = IFrame(html(picture2), width=300+ 20, height=300+20)
#variable to hold the outer frame
popup2 =folium.Popup(IFrame2,max_width=550)
#create variable to hold icon
icon2 = folium.Icon(color="red")


#variable where the first image will show
marker1 = folium.Marker([-28.16887518006333,27.938232421875],
                        popup=popup1,
                        tooltip=tooltip,
                        icon=icon1).add_to(map),

#variable where the first image will show
marker2 = folium.Marker([-27.69325634309157,26.19140625],
                        popup=popup2,
                        tooltip=tooltip,
                        icon=icon2).add_to(map),

#creating markers
folium.Marker([-25.20227,29.36340],
               popup='<strong>Location One</strong>').add_to(map)

#creating marker with different colors
folium.Marker([-26.29999,26.9999],
              popup='<strong>Location Two</strong>',
              icon=folium.Icon(color='green')).add_to(map)

#marker with image
folium.Marker([-25.25599,25.92329],
              popup='<strong>Location Three</strong>',
              icon=logoIcon).add_to(map)


#circular marker
folium.CircleMarker(location=[-25.20227,29.94363],
                    radius=30,
                    color='#428bca',
                    fill=True,
                    fill_color='#428bca').add_to(map)

#GeoJson overlay
folium.GeoJson(overlay, name='area').add_to(map)


#saving file to html
map.save('map.html')









